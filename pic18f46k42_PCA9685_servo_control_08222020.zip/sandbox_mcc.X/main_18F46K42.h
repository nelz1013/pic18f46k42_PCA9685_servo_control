/* 
 * File:   main_18F46K42.h
 * Author: nelson
 * Notes: header file to initialize MPLAB express board w/ PIC18F46K42 settings
 *      64MHz internal clock
 * Created on January 17, 2019, 10:39 AM
 */

// PIC18F46K42 Configuration Bit Settings

// 'C' source line config statements

#define _XTAL_FREQ 64000000
