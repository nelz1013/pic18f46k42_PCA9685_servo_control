/*
 * File:   main.c
 * Author: nelson
 *
 * Created on January 17, 2019, 2:55 PM
 */

#pragma warning disable 520 // Suppress those annoying MCC "function never called" messages

#include <xc.h>
#include "main_18F46K42.h"
#include <stdio.h>
#include <ctype.h>
#include <stdarg.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

//mcc includes
#include "./mcc_generated_files/mcc.h"

//custom includes
#include "../library/i2c_PCA9685_lib.h"

//custom includes
//#include "uart_lib.h"
//#include "i2c_PCA9685_lib.h"
//#include "timer2_lib.h"

//FTDI cable sets to COM7
//Baud rate is 9600

//uart txd = c6 = yellow
//uart rxd = c7 = orange
//i2c sda = c4 = purple
//i2c scl = RC3 = grey

int addr;
char pattern;

char d0Val = 0;

void main(void) {
    
    char ch;
    char i2c_data;
    
    //uart_init();
    SYSTEM_Initialize();
    INTCON0bits.GIEH = 1; //enable global high interrupts
    INTCON0bits.GIEL = 1; //enable global low interrupts
    INTCON0bits.IPEN = 1; //enable periphiral interrupts
    __delay_ms(5);
    printf("MCU booted\n");
    
    pca_init();
    initServoState();
    
    //test output
    TRISDbits.TRISD0 = 0;
    LATDbits.LATD0 = 0;
    
    while(1){
        
        pca_init();
        
        if (1) //test 90-0-90 servo 0 and servo 11
        {
            //change servo position to 0
            printf("\nSet Servo to 0\n");
            //setServoPos0(led_off_delay_H_0, led_off_delay_L_0);
            setServoPos(0, 0, 0);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 90
            printf("\nSet Servo to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 0, 90);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 180
            printf("\nSet Servo to 180\n");
            //setServoPos0(led_off_delay_H_180, led_off_delay_L_180);
            setServoPos(0, 0, 180);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 90
            printf("\nSet Servo to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 0, 90);
            printf("\n\n");
            __delay_ms(500);

            //exercise servo 11
            //change servo position to 0
            printf("\nSet Servo to 0\n");
            //setServoPos0(led_off_delay_H_0, led_off_delay_L_0);
            setServoPos(0, 11, 0);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 90
            printf("\nSet Servo to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 11, 90);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 180
            printf("\nSet Servo to 180\n");
            //setServoPos0(led_off_delay_H_180, led_off_delay_L_180);
            setServoPos(0, 11, 180);
            printf("\n\n");
            __delay_ms(500);

            //change servo position to 90
            printf("\nSet Servo to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 11, 90);
            printf("\n\n");
            __delay_ms(500);
        }//end test 90-0-90
        
        if (0) //set and hold at 90 to align
        {
             //change servo position to 90
            printf("\nSet Servo 0 to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 0, 90);
            printf("\n\n");
            __delay_ms(500);
            
             //change servo position to 90
            printf("\nSet Servo 11 to90\n");
            //setServoPos0(led_off_delay_H_90, led_off_delay_L_90);
            setServoPos(0, 11, 90);
            printf("\n\n");
            __delay_ms(500);
        }
        
        if (0) //test servoStat control
        {
            printf("\nSet Servo 0 to ON\n");
            setServoDigit(BRD0, 11, 1);
            printf("\n\n");
            __delay_ms(500);
            
            printf("\nSet Servo 0 to OFF\n");
            setServoDigit(BRD0, 11, 0);
            printf("\n\n");
            __delay_ms(500);
            
            printf("\nSet Servo 0 to ON\n");
            setServoDigit(BRD0, 11, 1);
            printf("\n\n");
            __delay_ms(500);    
            
        }
        
        d0Val = ~d0Val;
        LATDbits.LATD0 = d0Val;
        
        while (UART1_is_rx_ready())
        {
            ch = UART1_Read();
            if (isprint(ch)) {
                printf("ch = '%c'\r\n", ch);
            }
            else {
                printf("ch = 0x%02X\r\n", ch);
            }
        }
   }//end while (1)
}
