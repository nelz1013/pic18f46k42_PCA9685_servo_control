/*
 * File:   uart_lib.c
 * Author: nelson
 * Notes: PPS is not required on all PIC devices, if not needed, comment out
 *      If PPS is required, need to make sure to define all settings because defaults may not work properly
 *      BRGH and BRGL may not required for all PICs
 *      
 *      Receive is read on interrupts
 *          This is uses interrupt vector tables and may not be avilable on all devices
 *          another method is to check interrupt bits in one or more interrupt routines (slower)
 *          More info in X8C manual pg 200
 *          IVT is enabled by MVECEN in main header file
 * 
 *      printf() function is implemented by defining putch() command to point to uart_tx_char
 *          more info on printf and putch in XC8 pg 392
 * 
 *      rxBuffer created to constantly read RX interrupts and max size defined by rxBuffSize
 *          rxDone signla asserts when "Enter/Return" is sent at end of input string
 *          rxBuffer can be read directly to get string by other functions
 *          rxBuffer string count controlled by rxBuffCount, reset at CR or LR to zero
 *          Error output to terminal if # characters is > rxBuffSize
 *          In future implement software reset interrupt
 *          
 * 
 *  
 * Created on January 17, 2019, 10:38 AM
 */


#include <xc.h>
#include "../sandbox.X/main_18F46K42.h"
#include <stdio.h>
#include <stdarg.h>
#include <conio.h>
#include <stdbool.h>
#include <stdint.h>

//custom includes
#include "uart_lib.h"

unsigned char rxError;
unsigned char rxChar;
unsigned char rxDone;
unsigned char u1ErrorReg;
char rxBuffer[rxBuffSize];
unsigned char rxBuffCount;
unsigned char getCharCount;

void uart_init(void) {
    //setup UART xmit
    //set registers to control C6 for uart xmit
    ANSELCbits.ANSELC6 = 0; //turn off analog signals on C6
    TRISCbits.TRISC6 = 0; //set C6 as output
    //U1CTSPPS = 0b10110; //set C6 as xmit port in PPS
    RC6PPS = 0b010011; //set C6 as xmit port in PPS, table 17-2 pg 282
    
    //set 16-bit baud rate divider
    U1BRGH = 0x01; //upper bits of BRG divider
    U1BRGL = 0x9F; //64 mHz internal clock use 0x019F divider for 9600 baud
    U1CON0bits.BRGS = 0; //set high speed or low speed mode
    //U1CTSPPS = RC6PPS; //default RC6 pin
    
    //set uart mode and enable uart
    U1CON0bits.MODE = 0x0; //async 8-bit mode
    
    //setup UART RX
    //set registers to control C7 for uart RX
    ANSELCbits.ANSELC7 = 0; //turn off analog signals on C6
    TRISCbits.TRISC7 = 1; //set C7 as input
    U1RXPPS = 0b10111; //set C7 as RX port in PPS
    RC7PPS = 0b010101; //set C7 as RX port in PPS, table 17-2 pg 282
    
    //enable interrupts
    INTCON0bits.GIEH = 1;
    INTCON0bits.GIEL = 1;
    INTCON0bits.IPEN = 1;
    
    //receive interrupt 
    PIE3bits.U1RXIE = 1; //RX interrupt flag
    U1ERRIRbits.FERIF = 1; //framing error interrupt flag
    U1ERRIRbits.RXFOIF = 1; //2 byte FIFO over flow error interrupt flag
    
    //enable uart mode
    U1CON1bits.ON = 1; //enable xmit
    U1CON0bits.TXEN = 1; //enable xmit
    U1CON0bits.RXEN = 1; //enable UART RX
    //might be good to enable interrupts later to handle RX buffer over flows
          
    rxDone = 0;
    return;
}

void uart_tx_char(unsigned char byteIn) {
    while (PIR3bits.U1TXIF==0); //wait for TX buffer to be empty
    U1TXB = byteIn;
    return;
}

/*old single byte receive interrupt code, replace with larger buffer to use cgets()
 * void __interrupt(irq(U1RX), low_priority) uart_rx_interrupt(void) {
    //byte received successfully since error interrupt did not catch -- this is suppressed if error is detected
    u1ErrorReg = U1ERRIE;
    rxChar = U1RXB;
    //PIR3bits.U1TXIF=0;
    rxError = 0;
    rxDone = 1;
    return;
}
*/

void __interrupt(irq(U1RX), low_priority) uart_rx_interrupt(void) {
    //byte received successfully since error interrupt did not catch -- this is suppressed if error is detected
    u1ErrorReg = U1ERRIE;
    rxChar = U1RXB;
    //PIR3bits.U1TXIF=0;
    rxBuffer[rxBuffCount] = rxChar;
    rxBuffCount++;
    if (rxChar==CR || rxChar==LF) {
        rxBuffer[rxBuffCount-1] = 0; //null terminate string
        rxError = 0;
        rxDone = 1;        
        rxBuffCount = 0;
    }
    else if (rxBuffCount > rxBuffSize){
        printf("RX buffer over flow");
        rxBuffCount = 0;
        rxError = 1;
    };
    return;
}

void __interrupt(irq(U1E), high_priority) uart_rxError_interrupt(void) {
    //error detected,
    //flush FIFO until all errors are gone
    while (U1ERRIEbits.FERIE == 1 || U1ERRIEbits.RXFOIE == 1) {
    u1ErrorReg = U1ERRIE; //read error register to begin reset of errors
    rxChar = U1RXB; //read buffer to fully reset errors
    uart_tx_char('E');
    uart_tx_char(':');
    uart_tx_char(u1ErrorReg);
    uart_tx_char(':');
    uart_tx_char(rxChar);
    uart_tx_char(0x0D);
    U1ERRIEbits.RXFOIE=0;
    }    
    rxError = 1;
    return;
}

void putch(char byteIn) {
    uart_tx_char(byteIn);
}

/* This function did not seem to work with cgets or gets. just read rxBuffer directly
 * these functions may not work well with interrupt routine
 * char getche(void){
    char tempChar;
    tempChar = rxBuffer[getCharCount];
    uart_tx_char(tempChar);
    if(tempChar==LF || tempChar==CR || tempChar>=rxBuffSize) {
        getCharCount = 0;
        rxBuffCount = 0;
    }
    else {
        getCharCount++;
    }
    return tempChar;
}
*/