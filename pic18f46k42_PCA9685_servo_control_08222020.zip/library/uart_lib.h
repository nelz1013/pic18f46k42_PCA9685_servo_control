/* 
 * File:   uart_lib.h
 * Author: nelso
 *
 * Created on January 17, 2019, 2:57 PM
 */

#include <stdio.h>
#include <stdarg.h>
#include <conio.h>

extern unsigned char rxError;
extern unsigned char rxChar;
extern unsigned char rxDone;
extern unsigned char u1ErrorReg;
#define rxBuffSize 30
extern char rxBuffer[rxBuffSize];
extern unsigned char rxBuffCount;

//define key ascii hex values
#define EOT 0x04
#define CR 0x0D
#define LF 0x0A
    
void uart_init(void);
void uart_tx_char(unsigned char byteIn);
void __interrupt(irq(U1RX), low_priority) uart_rx_interrupt(void);
void __interrupt(irq(U1E), high_priority) uart_rxError_interrupt(void);
void putch(char byteIn);
char getche(void);
