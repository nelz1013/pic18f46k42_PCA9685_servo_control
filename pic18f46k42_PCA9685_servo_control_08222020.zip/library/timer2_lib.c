

#include <xc.h>
#include "../sandbox.X/main_18F46K42.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include <conio.h>

//custom includes

//variables
char tim2Val = 0;

void initTimer2(void)
{
    //Sets up timer2 as free running mode for 50 KHz output of timer2_postscaler output for I2C module
    T2HLTbits.MODE = 0x0; //free running mode - continually counts pg.340
    T2CLKbits.CS = 0x1; //Fosc/4 - pg. 336
    T2RSTbits.RSEL = 0x0; //no hardware reset
    T2CONbits.CKPS = 0x4; //set clock prescaler to generate 50 khz pg.339
    T2PR = 0x8; //use counter w/ CKPS to get 50 kHz SCL speed pg.338
    T2TMR = 0; //reset counter to zero
}

void timer2StartInt(void)
{
    //enable interrupts
    INTCON0bits.GIEH = 1;
    INTCON0bits.GIEL = 1;
    INTCON0bits.IPEN = 1;
    PIE4bits.TMR2IE = 1; //start timer 2 interrupt enable, mainly for testing
    tim2Val = 0;
}

void timer2StopInt(void)
{
    PIE4bits.TMR2IE = 0; //start timer 2 interrupt enable
}

void timer2Start(void)
{
    T2CONbits.ON = 0x1; //start running timer
}

void timer2Stop(void)
{
    T2CONbits.ON = 0; //stop timer
    T2TMR = 0; //reset counter to zero
}

void __interrupt(irq(TMR2)) timer2_interrupt(void) {
    tim2Val = ~tim2Val;
}
    