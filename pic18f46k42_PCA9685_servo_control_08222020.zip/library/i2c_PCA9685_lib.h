
#define PCA9685_ADD 0x40
#define pwmScaler 0x79
#define preScaleAdd 0xFE
#define runMode0 0x01 //turns off sleep mode to run servo
#define sleepMode0 0x11 //turns sleep mode set prescaler
#define mode0Add 0x00

//#led0 addresses
#define led0_on_L_add 0x06
#define led0_on_H_add 0x07
#define led0_off_L_add 0x08
#define led0_off_H_add 0x09

#define SERVO_NUM 16

#define BRD0 0

 /*
//middle position led0 reg values
//led0 ON delay = 4096*1.5ms/20ms = 0x133
#define led0_on_delay_H 0x00
#define led0_on_delay_L 0x00
#define led0_off_delay_H_0 0x01
#define led0_off_delay_L_0 0x33

//90 position led0 reg values
//led0 ON delay = 4096*2ms/20ms = 0x199
#define led0_on_delay_H_90 0x00
#define led0_on_delay_L_90 0x00
#define led0_off_delay_H_90 0x02
//#define led0_off_delay_H_90 0x02
//#define led0_off_delay_L_90 0x99
#define led0_off_delay_L_90 0x0F

//-90 position led0 reg values
//led0 ON delay = 4096*1ms/20ms = 0x0CC
#define led0_on_delay_H_m90 0x00
#define led0_on_delay_L_m90 0x00
#define led0_off_delay_H_m90 0x00
//#define led0_off_delay_L_m90 0xCC
#define led0_off_delay_L_m90 0x70
  * 
*/

//set values for angles from 0 to 180 degrees
#define led_on_delay_H 0x00 //this is the same for all angles
#define led_on_delay_L 0x00 //this si the same for all angles

//0 position all led regs
//led0 ON delay = 4096*1ms/20ms = 0x0CC
#define led_on_delay_H_0 0x00
#define led_on_delay_L_0 0x00
#define led_off_delay_H_0 0x00
//#define led0_off_delay_L_m90 0xCC
#define led_off_delay_L_0 0x70

//middle position all led regs = 90 degrees
//led0 ON delay = 4096*1.5ms/20ms = 0x133
#define led_on_delay_H_90 0x00
#define led_on_delay_L_90 0x00
#define led_off_delay_H_90 0x01
#define led_off_delay_L_90 0x33

//180 position all led regs
//led0 ON delay = 4096*2ms/20ms = 0x199
#define led_on_delay_H_180 0x00
#define led_on_delay_L_180 0x00
#define led_off_delay_H_180 0x02
//#define led0_off_delay_H_90 0x02
//#define led0_off_delay_L_90 0x99
#define led_off_delay_L_180 0x0F

void pca_init(void);
void setServoPos0(uint8_t delay_off_H, uint8_t delay_off_L);
void setServoPos(uint8_t boardNum, uint8_t ledNum, uint8_t angle);
void setServoDigit(uint8_t boardNum, uint8_t servoNum, bool onOff);
void initServoState(void);
