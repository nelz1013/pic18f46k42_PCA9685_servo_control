
extern char tim2Val;

void initTimer2(void);
void timer2Start(void);
void timer2Stop(void);
void timer2StartInt(void);
void timer2StopInt(void);

void __interrupt(irq(TMR2)) timer2_interrupt(void);
