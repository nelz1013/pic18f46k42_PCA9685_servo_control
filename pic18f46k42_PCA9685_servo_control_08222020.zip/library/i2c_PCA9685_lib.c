
#include <xc.h>
#include "../sandbox_mcc.X/main_18F46K42.h"
#include <stdio.h>
#include <stdarg.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

//mcc includes
#include "../sandbox_mcc.X/mcc_generated_files/i2c1.h"

//custom includes
#include "i2c_PCA9685_lib.h"

//define constant array with all led addresses
static const uint8_t LED_ON_L_ADD[16] = {
    0x06, //led0
    0x0A, //led1
    0x0E, //led2
    0x12, //led3
    0x16, //led4
    0x1A, //led5
    0x1E, //led6
    0x22, //led7
    0x26, //led8
    0x2A, //led9
    0x2E, //led10
    0x32, //led11
    0x36, //led12
    0x3A, //led13
    0x3E, //led14
    0x42 //led15
};

static const uint8_t LED_ON_H_ADD[16] = {
    0x07, //led0
    0x0B, //led1
    0x0F, //led2
    0x13, //led3
    0x17, //led4
    0x1B, //led5
    0x1F, //led6
    0x23, //led7
    0x27, //led8
    0x2B, //led9
    0x2F, //led10
    0x33, //led11
    0x37, //led12
    0x3B, //led13
    0x3F, //led14
    0x43 //led15
};

static const uint8_t LED_OFF_L_ADD[16] = {
    0x08, //led0
    0x0C, //led1
    0x10, //led2
    0x14, //led3
    0x18, //led4
    0x1C, //led5
    0x20, //led6
    0x24, //led7
    0x28, //led8
    0x2C, //led9
    0x30, //led10
    0x34, //led11
    0x38, //led12
    0x3C, //led13
    0x40, //led14
    0x44 //led15
};

static const uint8_t LED_OFF_H_ADD[16] = {
    0x09, //led0
    0x0D, //led1
    0x11, //led2
    0x15, //led3
    0x19, //led4
    0x1D, //led5
    0x21, //led6
    0x25, //led7
    0x29, //led8
    0x2D, //led9
    0x31, //led10
    0x35, //led11
    0x39, //led12
    0x3D, //led13
    0x41, //led14
    0x45 //led15
};

static const uint8_t BRD_ADDRESSES[2] =
{
    PCA9685_ADD,
    0x00
};

enum servoOnOff{off1, off1_on, off2, off2_on}; 
static enum servoOnOff servoState[16];

void pca_init(void)
{
    uint8_t i2c_data;
    __delay_ms(5);
    printf("\n===========================\n");
    printf("\nInitialize\n");
    i2c_data = i2c1_read1ByteRegister(0x40, mode0Add);
    printf("1: Test Mode0 = 0x%02X\r\n", i2c_data);
    __delay_ms(5);

    i2c_data = i2c1_read1ByteRegister(0x40, preScaleAdd);
    printf("2: PreScale = 0x%02X\r\n", i2c_data);
    
    printf("3: Write Mode0 = 0x%02X\n", sleepMode0);
    i2c1_write1ByteRegister(0x40, mode0Add, sleepMode0);
    __delay_ms(5);
    i2c_data = i2c1_read1ByteRegister(0x40, mode0Add);
    printf("4: Read Mode0 = 0x%02X\r\n", i2c_data);
    __delay_ms(5);

    //setup servo registers
    printf("5: Write PreScale = 0x%02X\n", pwmScaler);
    i2c1_write1ByteRegister(0x40, preScaleAdd, pwmScaler);
    __delay_ms(5);

    i2c_data = i2c1_read1ByteRegister(0x40, preScaleAdd);
    printf("6: Read PreScale = 0x%02X\r\n", i2c_data);

    printf("7: Write Mode0 =  0x%02X\n", runMode0);
    i2c1_write1ByteRegister(0x40, mode0Add, runMode0);
    __delay_ms(5);
    i2c_data = i2c1_read1ByteRegister(0x40, mode0Add);
    printf("8: Read Mode0 = 0x%02X\r\n", i2c_data);
    __delay_ms(5);
    return;
}

void setServoPos0(uint8_t delay_off_H, uint8_t delay_off_L)
{
    uint8_t i2c_data;
    i2c1_write1ByteRegister(0x40, led0_on_L_add, led_on_delay_L);
    i2c1_write1ByteRegister(0x40, led0_on_H_add, led_on_delay_H);
    i2c1_write1ByteRegister(0x40, led0_off_L_add, delay_off_L);
    i2c1_write1ByteRegister(0x40, led0_off_H_add, delay_off_H);
    i2c_data = i2c1_read1ByteRegister(0x40, led0_off_L_add);
    printf("led0 off L = 0x%02X\r\n", i2c_data);
    i2c_data = i2c1_read1ByteRegister(0x40, led0_off_H_add);
    printf("led0 off H = 0x%02X\r\n", i2c_data);
}

void setServoPos(uint8_t boardNum, uint8_t ledNum, uint8_t angle)
{
    uint8_t i2c_data;
    uint8_t delay_off_L, delay_off_H;
    
    switch (angle) //use switch to determine angle. default to 0 if > 180
    {
        case 90:
            delay_off_L = led_off_delay_L_90;
            delay_off_H = led_off_delay_H_90;
            break;
        
        case 180:
            delay_off_L = led_off_delay_L_180;
            delay_off_H = led_off_delay_H_180;
            break;
            
        default:
            delay_off_L = led_off_delay_L_0;
            delay_off_H = led_off_delay_H_0;
    }     
            
    
    i2c1_write1ByteRegister(BRD_ADDRESSES[boardNum], LED_ON_L_ADD[ledNum], led_on_delay_L);
    i2c1_write1ByteRegister(BRD_ADDRESSES[boardNum], LED_ON_H_ADD[ledNum], led_on_delay_H);
    i2c1_write1ByteRegister(BRD_ADDRESSES[boardNum], LED_OFF_L_ADD[ledNum], delay_off_L);
    i2c1_write1ByteRegister(BRD_ADDRESSES[boardNum], LED_OFF_H_ADD[ledNum], delay_off_H);
    i2c_data = i2c1_read1ByteRegister(BRD_ADDRESSES[boardNum], LED_OFF_L_ADD[ledNum]);
    printf("led off L = 0x%02X\r\n", i2c_data);
    i2c_data = i2c1_read1ByteRegister(BRD_ADDRESSES[boardNum], LED_OFF_H_ADD[ledNum]);
    printf("led off H = 0x%02X\r\n", i2c_data);
}

void setServoDigit(uint8_t boardNum, uint8_t servoNum, bool onOff)
{
    enum servoOnOff nowServoState = servoState[servoNum];
    //enum servoOnOff{off1, off1_on, off2, off2_on}; 
    printf("%d servo state = %d\n", servoNum, nowServoState);
    
    switch (nowServoState)
    {
        case off1:
            if (onOff==1) //turn on
            {
                printf("Turn on %d from off1\n", servoNum);
                setServoPos(boardNum, servoNum, 90);
                servoState[servoNum] = off1_on;
            }
            break;
        case off1_on:
            if (onOff==0) //turn off to off2
            {
                printf("Turn off %d from off1_on\n", servoNum);
                setServoPos(boardNum, servoNum, 180);
                servoState[servoNum] = off2;
            }
            break;
        case off2_on:
            if (onOff==0) //turn off to off1
            {
                printf("Turn off %d from off2_on\n", servoNum);
                setServoPos(boardNum, servoNum, 0);
                servoState[servoNum] = off1;
            }
            break;
        case off2:
            if (onOff==1) // turn on
            {
                printf("Turn on %d from off2\n", servoNum);
                setServoPos(boardNum, servoNum, 90);
                servoState[servoNum] = off2_on;
            }
            break;
        default:
            printf("State not detected\n");
            break;
    }
}

void initServoState(void)
{
    int servoCnt = 0;
    for (servoCnt = 0; servoCnt<SERVO_NUM; servoCnt++)
    {
        servoState[servoCnt] = off1;
    }
}

